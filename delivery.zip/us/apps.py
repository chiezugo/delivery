from django.apps import AppConfig


class UsConfig(AppConfig):
    name = 'us'
